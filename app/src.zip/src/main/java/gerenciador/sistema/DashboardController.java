package gerenciador.sistema;

import gerenciador.interfaces.UsuarioNecessario;

public class DashboardController implements UsuarioNecessario{
    
}
